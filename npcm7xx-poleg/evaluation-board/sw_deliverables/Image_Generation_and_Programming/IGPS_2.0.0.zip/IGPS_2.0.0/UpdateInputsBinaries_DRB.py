# SPDX-License-Identifier: GPL-2.0
#
# Nuvoton IGPS: Image Generation And Programming Scripts For Poleg BMC
#
# Copyright (C) 2018 Nuvoton Technologies, All Rights Reserved
#-------------------------------------------------------------------------

import sys
import os

from shutil import copyfile
from ImageGeneration.version_vars import *

import ImageGeneration.UpdateInputsBinaries
import ImageGeneration.GenerateImages


versions_dir = os.path.join("ImageGeneration", "versions")
ref_dir = os.path.join("ImageGeneration", "references")

BootBlock_bin_source = os.path.join(versions_dir, bootblock_poleg)
BBheader_xml_source = os.path.join(ref_dir, "BootBlockAndHeader_DRB.xml")

uboot_bin_source = os.path.join(versions_dir, uboot_drb)
Ubootheader_xml_source = os.path.join(ref_dir, "UbootHeader_DRB.xml")

try:

	print("--------------------------------------")
	print("Updating input binaries for Dell's DRB")
	print("--------------------------------------")

	if not os.path.isdir(ref_dir):
		os.mkdir(ref_dir)

	ImageGeneration.UpdateInputsBinaries.copy_bootblock_files(BootBlock_bin_source, BBheader_xml_source)
	ImageGeneration.UpdateInputsBinaries.copy_uboot_files(uboot_bin_source, Ubootheader_xml_source)


	print("---------------------------------------------")
	print("Binaries for Dell's DRB are ready in 'inputs'")
	print("---------------------------------------------")

except (IOError) as e:
	print("Error Updating input Binaries (%s)" % (e.strerror))
except:
	print("Error Updating input Binaries")
